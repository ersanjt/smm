# Favicon Files

Place your favicon files in this directory:

- `favicon.ico` - Standard favicon (16x16, 32x32, 48x48)
- `favicon-16x16.png` - 16x16 PNG favicon
- `favicon-32x32.png` - 32x32 PNG favicon
- `favicon-180x180.png` - Apple touch icon (180x180)

## How to create favicon:

1. Use an online tool like https://favicon.io
2. Upload your logo image
3. Download all sizes
4. Place them in this directory

Or use a tool like https://realfavicongenerator.net/

## Current status:
These are placeholder paths. Upload actual favicon files to complete the setup.

